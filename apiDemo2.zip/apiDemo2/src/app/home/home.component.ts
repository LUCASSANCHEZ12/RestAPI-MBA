import { Component } from '@angular/core';
import { ApiService } from '../service/api.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrl: './home.component.css'
})
export class HomeComponent {

  data: any[] = [];

  constructor(private apiService: ApiService){}
  ngOnInit(): void{
    this.llenarDatos();
  }

  llenarDatos(){
    this.apiService.getuser().subscribe(data => {
      this.data = data;
      console.log(this.data);
    })
  }
}
