import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ApiService {
//http://24.144.89.34:8080/MBA/Chatbot/getall
//http://jsonplaceholder.typicode.com/todos
  private urlAPI = 'http://24.144.89.34:8080/MBA/Chatbot/getall';
  
  constructor(private http: HttpClient) { }

  public getuser(): Observable<any> {
    return this.http.get<any>(this.urlAPI)
  }
}
